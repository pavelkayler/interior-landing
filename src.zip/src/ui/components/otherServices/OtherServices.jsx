import { Container } from "react-bootstrap";

const OtherServices = () => {
  return (
    <Container>
      <h2 className="sectionTitle">Прочие услуги</h2>

      <div className="block">
        <ul className="sectionText" style={{ margin: 0, paddingLeft: 18 }}>
          <li>Консультация</li>
          <li>Планировочное решение</li>
          <li>Подбор материалов</li>
          <li>Комплектация</li>
          <li>Авторский надзор</li>
        </ul>
      </div>
    </Container>
  );
};

export default OtherServices;
