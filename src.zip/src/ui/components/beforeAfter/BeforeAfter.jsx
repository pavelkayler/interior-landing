import { Container, Row, Col } from "react-bootstrap";

const BeforeAfter = () => {
  return (
    <Container>
      <h2 className="sectionTitle">До / После</h2>

      <Row className="g-3">
        <Col md={6}>
          <div className="block">
            <div className="sectionText">Заглушка: До</div>
          </div>
        </Col>
        <Col md={6}>
          <div className="block">
            <div className="sectionText">Заглушка: После</div>
          </div>
        </Col>
      </Row>
    </Container>
  );
};

export default BeforeAfter;
