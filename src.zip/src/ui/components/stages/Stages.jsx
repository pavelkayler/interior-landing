import { Container } from "react-bootstrap";

const Stages = () => {
  return (
    <Container>
      <h2 className="sectionTitle">Этапы работы</h2>
      <div className="block">
        <ol className="sectionText" style={{ margin: 0, paddingLeft: 18 }}>
          <li>Бриф / постановка задачи</li>
          <li>Обмеры / план</li>
          <li>Планировочные решения</li>
          <li>Концепция</li>
          <li>Визуализация</li>
          <li>Рабочая документация</li>
          <li>Комплектация (опц.)</li>
          <li>Авторский надзор (опц.)</li>
        </ol>
      </div>
    </Container>
  );
};

export default Stages;
