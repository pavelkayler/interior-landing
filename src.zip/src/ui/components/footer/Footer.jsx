import { Container, Row, Col, Button } from "react-bootstrap";

const Footer = () => {
  return (
    <Container>
      <h2 className="sectionTitle">Контакты</h2>

      <Row className="g-3">
        <Col md={6}>
          <div className="block">
            <div className="sectionText">
              Заглушка: телефон / telegram / instagram / email
            </div>
            <div style={{ height: 12 }} />
            <Button variant="light">Написать</Button>
          </div>
        </Col>

        <Col md={6}>
          <div className="block">
            <div className="sectionText">
              Заглушка: ИП Демидова, реквизиты, политика.
            </div>
          </div>
        </Col>
      </Row>
    </Container>
  );
};

export default Footer;
