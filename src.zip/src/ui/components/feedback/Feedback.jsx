import { Container, Row, Col } from "react-bootstrap";

const Feedback = () => {
  return (
    <Container>
      <h2 className="sectionTitle">Отзывы</h2>

      <Row className="g-3">
        {Array.from({ length: 3 }).map((_, i) => (
          <Col md={4} key={i}>
            <div className="block">
              <div className="sectionText">Заглушка отзыва #{i + 1}</div>
            </div>
          </Col>
        ))}
      </Row>
    </Container>
  );
};

export default Feedback;
