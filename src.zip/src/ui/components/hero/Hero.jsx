import { Container, Button, Row, Col } from "react-bootstrap";
import "./hero.css";

const scrollToId = (id) => {
  const el = document.getElementById(id);
  if (!el) return;
  el.scrollIntoView({ behavior: "smooth", block: "start" });
};

const Hero = () => {
  return (
    <div className="hero">
      <div className="hero__bg" />
      <div className="hero__overlay" />

      <Container className="hero__container">
        <Row className="hero__row">
          <Col lg={7} className="hero__leftCol">
            <div className="hero__left">
              <div className="hero__kicker">
                Дизайн интерьера • визуализация • чертежи
              </div>

              <h1 className="hero__title">
                Дизайн интерьера, в котором спокойно жить
              </h1>

              <p className="hero__subtitle">
                Я продаю не проект, а ощущения. При этом — планировка,
                документация и смета, чтобы ремонт прошёл без сюрпризов.
              </p>

              <div className="hero__cta">
                <Button
                  variant="light"
                  className="hero__btn hero__btnPrimary"
                  onClick={() => scrollToId("contacts")}
                >
                  Бесплатная консультация
                </Button>

                <Button
                  variant="outline-light"
                  className="hero__btn hero__btnSecondary"
                  onClick={() => scrollToId("stages")}
                >
                  Как проходит работа
                </Button>
              </div>

              <div className="hero__chips">
                <div className="hero__chip">
                  <div className="hero__chipTitle">Планировка</div>
                  <div className="hero__chipText">удобство</div>
                </div>

                <div className="hero__chip">
                  <div className="hero__chipTitle">Визуализация</div>
                  <div className="hero__chipText">атмосфера</div>
                </div>

                <div className="hero__chip">
                  <div className="hero__chipTitle">Чертежи</div>
                  <div className="hero__chipText">безопасность</div>
                </div>

                <div className="hero__chip">
                  <div className="hero__chipTitle">Бюджет</div>
                  <div className="hero__chipText">спокойствие</div>
                </div>
              </div>

              <div className="hero__micro">
                <span className="hero__microItem">Сроки: от 7 дней</span>
                <span className="hero__dot" />
                <span className="hero__microItem">Формат: онлайн / офлайн</span>
                <span className="hero__dot" />
                <span className="hero__microItem">
                  Документация: полный комплект
                </span>
              </div>
            </div>
          </Col>

          <Col lg={5} className="hero__rightCol">
            <div className="hero__right">
              <div className="heroCard">
                <div className="heroCard__top">
                  <div className="heroCard__title">Быстрый старт</div>
                  <div className="heroCard__badge">Бесплатно</div>
                </div>

                <div className="heroCard__text">
                  15 минут: цели, стиль, бюджет, сроки. После — план действий и
                  понимание стоимости.
                </div>

                <div className="heroCard__preview">
                  <div className="heroCard__previewBox heroCard__previewBox--big">
                    <div className="heroCard__previewLabel">Атмосфера</div>
                    <div className="heroCard__previewHint">
                      сюда вставим фото/рендер
                    </div>
                  </div>

                  <div className="heroCard__previewCol">
                    <div className="heroCard__previewBox heroCard__previewBox--small">
                      <div className="heroCard__previewLabel">План</div>
                    </div>
                    <div className="heroCard__previewBox heroCard__previewBox--small">
                      <div className="heroCard__previewLabel">Чертеж</div>
                    </div>
                  </div>
                </div>

                <div className="heroCard__actions">
                  <Button
                    variant="light"
                    className="heroCard__btn"
                    onClick={() => scrollToId("contacts")}
                  >
                    Записаться
                  </Button>

                  <Button
                    variant="outline-light"
                    className="heroCard__btn"
                    onClick={() => scrollToId("services")}
                  >
                    Почему выбирают нас
                  </Button>
                </div>

                <div className="heroCard__fineprint">
                  Нажимая “Записаться”, вы соглашаетесь на обработку данных.
                </div>
              </div>
            </div>
          </Col>
        </Row>
      </Container>
    </div>
  );
};

export default Hero;
