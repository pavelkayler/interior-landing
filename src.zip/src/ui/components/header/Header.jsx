import { Container, Navbar, Nav, Button } from "react-bootstrap";
import { Link } from "react-router-dom";
import "./header.css";

const navItems = [
  { id: "hero", label: "Главная" },
  { id: "about", label: "О нас" },
  { id: "principles", label: "Принципы" },
  { id: "stages", label: "Этапы" },
  { id: "photos", label: "Реализации" },
  { id: "feedback", label: "Отзывы" },
  { id: "contacts", label: "Контакты" },
];

const scrollToId = (id) => {
  const el = document.getElementById(id);
  if (!el) return;
  el.scrollIntoView({ behavior: "smooth", block: "start" });
};

const Header = () => {
  return (
    <Navbar expand="lg" className="appHeader" variant="dark">
      <Container>
        <Navbar.Brand
          className="appHeader__brand"
          onClick={() => scrollToId("hero")}
        >
          DEMIDOVA
        </Navbar.Brand>

        <Navbar.Toggle aria-controls="main-nav" />

        <Navbar.Collapse id="main-nav">
          <Nav className="me-auto appHeader__nav">
            {navItems.map((item) => (
              <Nav.Link
                key={item.id}
                className="appHeader__link"
                onClick={() => scrollToId(item.id)}
              >
                {item.label}
              </Nav.Link>
            ))}
          </Nav>

          <div className="appHeader__actions">
            <Link className="appHeader__portfolioLink" to="/portfolio">
              Портфолио
            </Link>

            <Button
              variant="light"
              className="appHeader__cta"
              onClick={() => scrollToId("contacts")}
            >
              Бесплатная консультация
            </Button>
          </div>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
};

export default Header;
