import { Container, Row, Col } from "react-bootstrap";

const Photos = () => {
  return (
    <Container>
      <h2 className="sectionTitle">Фото реализаций</h2>

      <Row className="g-3">
        {Array.from({ length: 6 }).map((_, i) => (
          <Col md={4} key={i}>
            <div className="block">
              <div className="sectionText">Заглушка фото #{i + 1}</div>
            </div>
          </Col>
        ))}
      </Row>
    </Container>
  );
};

export default Photos;
