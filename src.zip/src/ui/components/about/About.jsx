import { Container } from "react-bootstrap";

const About = () => {
  return (
    <Container>
      <h2 className="sectionTitle">О нас</h2>
      <div className="block">
        <p className="sectionText">
          Заглушка: здесь будет короткий текст о студии/авторе, опыт, подход,
          ценности.
        </p>
      </div>
    </Container>
  );
};

export default About;
