import { Container, Row, Col } from "react-bootstrap";

const Principles = () => {
  return (
    <Container>
      <h2 className="sectionTitle">Наши принципы</h2>

      <Row className="g-3">
        <Col md={6}>
          <div className="block">
            <h3 className="h5 mb-2">Планировка = удобство</h3>
            <p className="sectionText">
              Заглушка: логика пространства, сценарии жизни, хранение.
            </p>
          </div>
        </Col>

        <Col md={6}>
          <div className="block">
            <h3 className="h5 mb-2">Визуализация = атмосфера</h3>
            <p className="sectionText">
              Заглушка: свет, фактуры, настроение до начала ремонта.
            </p>
          </div>
        </Col>

        <Col md={6}>
          <div className="block">
            <h3 className="h5 mb-2">Чертежи = безопасность</h3>
            <p className="sectionText">
              Заглушка: точные планы для строителей без “догадок”.
            </p>
          </div>
        </Col>

        <Col md={6}>
          <div className="block">
            <h3 className="h5 mb-2">Бюджет = спокойствие</h3>
            <p className="sectionText">
              Заглушка: прозрачность сметы и контроль расходов.
            </p>
          </div>
        </Col>
      </Row>
    </Container>
  );
};

export default Principles;
