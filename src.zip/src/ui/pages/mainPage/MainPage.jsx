import Header from "../../components/header/Header.jsx";
import Hero from "../../components/hero/Hero.jsx";
import About from "../../components/about/About.jsx";
import Principles from "../../components/principles/Principles.jsx";
import Stages from "../../components/stages/Stages.jsx";
import Photos from "../../components/photos/Photos.jsx";
import BeforeAfter from "../../components/beforeAfter/BeforeAfter.jsx";
import Feedback from "../../components/feedback/Feedback.jsx";
import OtherServices from "../../components/otherServices/OtherServices.jsx";
import Footer from "../../components/footer/Footer.jsx";

const MainPage = () => {
  return (
    <>
      <Header />

      <section id="hero">
        <Hero />
      </section>

      <section id="about" className="section">
        <About />
      </section>

      <section id="principles" className="section">
        <Principles />
      </section>

      <section id="stages" className="section">
        <Stages />
      </section>

      <section id="photos" className="section">
        <Photos />
      </section>

      <section id="beforeAfter" className="section">
        <BeforeAfter />
      </section>

      <section id="feedback" className="section">
        <Feedback />
      </section>

      <section id="otherServices" className="section">
        <OtherServices />
      </section>

      <section id="contacts" className="section">
        <Footer />
      </section>
    </>
  );
};

export default MainPage;
