import { Container } from "react-bootstrap";

const PortfolioPage = () => {
  return (
    <Container className="section">
      <h1 className="sectionTitle">Портфолио</h1>
      <div className="block">
        <p className="sectionText">Заглушка страницы портфолио.</p>
      </div>
    </Container>
  );
};

export default PortfolioPage;
